# mypackage
This library was created as an example of how to create your own Python package.

# How to install 
Please follow the below instruction on how to install the software, software to be installed by IT department